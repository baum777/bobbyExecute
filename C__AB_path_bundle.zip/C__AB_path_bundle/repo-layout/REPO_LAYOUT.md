# Repo Layout — Canonical (C > A == B)

```
dot-dot/
  bot/                                 # TypeScript — Governance Core (C) + pipeline
    src/
      agents/
        ingest-agent.ts
        signal-agent.ts                # builds CQD + pattern candidates (A inputs) + MCI/BCI + user-intent features
        risk-agent.ts                  # governance risk scoring + hard blocks (C)
        execute-agent.ts
        verify-agent.ts
        journal-agent.ts               # event store + deterministic hash chain (C)
        monitor-agent.ts
      governance/
        policy-engine.ts
        guardrails.ts
        circuit-breaker.ts
        review-gates.ts
      core/
        cqd/
          cqd-builder.ts
          cqd-hash.ts
        determinism/
          canonicalize.ts
          hash.ts
          decision-token.ts
        state/
          event-store.ts               # append-only
          rolling-views.ts             # TTL views
      api/
        routes/
          health.ts
          ready.ts
          cqd.ts
          decision.ts
          trade.ts
          audit.ts
      adapters/
        dexscreener.ts
        dexpapi.ts
        moralis.ts
        rpc-verify.ts
        x-timeline.ts
      config/
        config.schema.json
        config.ts
    tests/
      harness/
        fail-closed.test.ts
      golden-tasks/
        GT-001_pipeline_smoke.test.ts
        GT-002_missing_feed_fail_closed.test.ts
        GT-003_conflict_sources_fail_closed.test.ts
        GT-004_mci_bci_block.test.ts
        GT-005_fragile_liquidity_no_hype.test.ts
        GT-006_execute_verify_race.test.ts
        GT-007_journal_replay_recovery.test.ts
        GT-008_rate_limit_adapter.test.ts
        GT-009_review_gate_hold.test.ts
        GT-010_decision_token_verify.test.ts

  packages/
    core-trading/                       # Shared contracts + schemas + determinism utils
      src/
        contracts/
          market.ts
          token.ts
          cqd.ts
          decision.ts
          trade.ts
          journal.ts
          wallet.ts
        schemas/
          cqd.snapshot.v1.schema.json
          decision.token.v1.schema.json
        determinism/
          canonicalize.ts
          hash.ts

  dor-bot/                              # Python — Feature Lab + UI + bridge client (A/B/UX)
    pattern_lab/
      patterns.py
      qlearning.py
      feature_extractors.py
    bridge_client/
      client.py                         # calls Governance API
      types.py                          # generated from OpenAPI/schemas
    ui_console/
      server.py                         # UI only; no trading authority
      dashboard.html
    start.py
    requirements.txt
```

## Invariants
- Only **bot/** executes trades in production mode.
- Python may propose A/B outputs but must receive a valid `decision_token` before execution.
- All decisions are hash-logged and replayable via event sourcing.
