# Pattern Engine Spec (A)

**Version:** 1.0  
**Date:** 2026-03-04

## Contract
A consumes CQD only and outputs `PatternCandidate[]`:
- pattern_id
- quality_score (0..100)
- expected_rr
- invalidation rule
- evidence_refs
- features_used

## Pattern library (initial)
- P-001 Liquidity Expansion Breakout
- P-002 ATR Compression → Expansion
- P-003 2nd Wave Pullback Continuation
- P-004 Mean Reversion Overshoot
- P-005 Narrative Ignition (X-led; requires organic_score >= 60)
- P-900 Rug-Precursor (block pattern)

## Fail-closed
If CQD invalid or missing hash → return empty set.
