# Determinism & Canonicalization Spec

**Version:** 1.0  
**Date:** 2026-03-04

## Canonical JSON rules
- UTF-8 JSON, no whitespace
- sort object keys lexicographically
- preserve array order
- remove volatile fields before hashing: `hash`, `signature`, `received_at`
- float normalization:
  - default: round to 6 decimals
  - percent-return fields: round to 4 decimals
- include `schema_version`

## Hash
- SHA-256
- output: lowercase hex

## Journal hash chain
Each `journal.event.v1` includes:
- `prev_event_hash` (nullable for genesis)
- `event_hash = sha256(canonicalize(event_without_event_hash))`

## Cross-language invariant
Same canonical payload must hash identically in:
- TypeScript (Node)
- Python (bridge verifier)
