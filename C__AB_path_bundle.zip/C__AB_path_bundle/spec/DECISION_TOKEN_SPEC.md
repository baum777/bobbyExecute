# Decision Token Spec (Authorization Artifact)

**Version:** 1.0  
**Date:** 2026-03-04

## Payload (deterministic)
- decision_id
- cqd_hash
- pattern_id (nullable)
- sizing_hash (nullable)
- policy_hash
- gates_hash
- created_at_bucket / expires_at_bucket
- action: EXECUTE | HOLD | BLOCK
- prev_journal_hash

## Hash-only vs signed
- Dev/dry-run: token_hash only (sha256 canonical payload)
- Prod: token_hash + ed25519 signature over token_hash

## Validity
- not expired
- gates PASS
- action == EXECUTE
- signature verify (if present)

Fail-closed on any mismatch.
