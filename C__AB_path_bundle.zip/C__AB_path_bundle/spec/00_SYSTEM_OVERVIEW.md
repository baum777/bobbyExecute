# System Spec Overview — C > A == B

**Version:** 1.0  
**Date:** 2026-03-04

## Objective
A governance-first trading system with:
- deterministic audit trail (canonicalize → hash → journal)
- fail-closed gating
- event-sourced recovery
- CQD (compressed quality dataset) as the sole reasoning input

## Canonical flow
1) Ingest (multi-source)  
2) Validate (confidence, staleness, divergence)  
3) Build CQD snapshot (features + evidence + hash)  
4) Pattern candidates (A) — CQD-only  
5) Governance evaluation (C) — gates + risk score  
6) Sizing proposal (B) — cashflow sizing + caps  
7) Decision preview (deterministic)  
8) Decision token (authorization)  
9) Execute → Verify  
10) Journal → Monitor (feedback loop)
