# Governance Spec (C)

**Version:** 1.0  
**Date:** 2026-03-04

## Principles
- Fail-closed by default
- Hard gates > soft guides
- Deterministic, auditable decisions
- Secrets never in repo files (keys via vault/env)

## Inputs
- CQD snapshot (hashed)
- Pattern candidate(s) (A)
- Sizing proposal (B)
- Policy config (schema-validated)

## Outputs
- Decision preview (deterministic hash)
- Decision token (authorization; hash + optional signature)

## Hard gates (BLOCK / HOLD)
BLOCK if:
1) CQD invalid OR confidence < 0.70
2) Integrity gate: if mci < 45 AND bci < 45 → BLOCK
3) overall_risk_score >= 85 → BLOCK
4) liquidity_stability_score < 35 → BLOCK
5) circuit breaker tripped → BLOCK

HOLD if:
- review required AND approval missing

## Soft guides (dynamic)
- Hype high + organic low → size multiplier <= 0.6
- Panic high → size multiplier <= 0.7 and entry throttling
- Thin/Fragile liquidity → prohibit breakout patterns
