# Sizing Engine Spec (B)

**Version:** 1.0  
**Date:** 2026-03-04

## Objective
Cashflow-first sizing with variance control.

## Base rule
risk_budget_bps = base_risk_bps × quality_multiplier × regime_multiplier × equity_multiplier

## Suggested safe bounds (memecoins)
- base_risk_bps: 25..75 (0.25%..0.75% of equity)
- always capped by policy max risk/trade

## Equity curve control (examples)
- drawdown → 0.7
- neutral → 1.0
- uptrend → 1.1..1.2 (capped)

## Fail-closed
If CQD invalid or policy caps missing → no sizing proposal.
