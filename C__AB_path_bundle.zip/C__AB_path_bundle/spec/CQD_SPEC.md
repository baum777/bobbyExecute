# CQD Spec — Compressed Quality Dataset

**Version:** 1.0  
**Date:** 2026-03-04  
**Bucket:** 60s per token (`ts_bucket = unix_ms // 60000`)

## Purpose
CQD is the *only* dataset allowed to enter the reasoning stage (A/B).  
It is compact, high-signal, and deterministically hashable.

## Required fields
- `token`, `chain`, `ts_bucket`
- `features` (normalized; prefer 0..100 where applicable)
- `confidence` (0..1)
- `anomaly_flags[]`
- `evidence_pack[]` length 3..7, each <= 140 chars
- `sources` (freshness + divergence)
- `hash` (sha256 of canonical snapshot without `hash`)

## Suggested feature groups
### Onchain microstructure
- price_return_1m (%)
- volume_1m
- liquidity_depth
- liquidity_change_5m (%)
- spread_proxy (0..100)
- atr_1m

### Forensic integrity
- top10_share (0..100)
- holder_hhi (0..100)
- mci (0..100)
- bci (0..100)
- hybrid_integrity (0..100)

### Narrative / X
- mention_rate (0..100)
- influencer_weighted_mentions (0..100)
- sentiment_score (-1..1)
- hype_density (0..100)
- panic_density (0..100)
- organic_score (0..100)
- amplified_score (0..100)

## Fail-closed validity
Snapshot invalid if:
- confidence < 0.70
- missing required feature groups (policy-defined)
- now - freshest_source_ts_ms > max_staleness_ms
- divergence above thresholds (policy-defined)
