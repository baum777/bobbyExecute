# Golden Tasks Plan (GT-001..GT-010)

**Version:** 1.0  
**Date:** 2026-03-04

GT-001 Pipeline smoke  
GT-002 Missing feed → fail-closed  
GT-003 Conflicting sources → fail-closed  
GT-004 MCI/BCI both <45 → block  
GT-005 Fragile liquidity + hype → no breakout  
GT-006 Execute/Verify race guard  
GT-007 Journal replay recovery  
GT-008 Adapter rate limiting  
GT-009 Review gate hold  
GT-010 Decision token verification  
