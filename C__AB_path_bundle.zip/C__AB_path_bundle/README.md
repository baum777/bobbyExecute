# C__AB_path — Governance-First Trading System Bundle

**Version:** 1.0  
**Date:** 2026-03-04  
**Principle:** **C > A == B** (Governance dominates; Pattern (A) and Sizing (B) are equal subsystems under C)

## Contents
- `repo-layout/REPO_LAYOUT.md` — canonical repo tree + invariants
- `spec/` — full system specs (CQD, Governance, Pattern, Sizing, Determinism, Decision Token, Golden Tasks)
- `contracts/ts/` — TypeScript contracts (shared)
- `contracts/json-schemas/` — JSON Schemas for runtime validation
- `openapi/governance-api.v1.yaml` — Governance API (v1)
- `packages/core-trading/` — publishable shared package skeleton (contracts + schemas)

## Non-negotiables
- Only **bot/** executes trades in production mode.
- Python may request execution but must obtain a valid **Decision Token** from Governance (C).
- Every decision is deterministic and journaled in an append-only hash chain.
