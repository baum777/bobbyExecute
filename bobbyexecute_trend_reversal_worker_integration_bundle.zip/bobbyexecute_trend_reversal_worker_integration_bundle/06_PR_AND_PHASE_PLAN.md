# 06 — PR and Phase Plan

## Immediate next sequence

### PR-W1-02
Wave 1 upstream chain and `DataQualityV1`

### PR-W1-03
CQD boundary and replay fixtures

### PR-W2-01
Signal/forensics foundation for reversal monitoring

Scope:
- line derivation helpers
- market structure inputs
- flow/holder-derived feature inputs
- deterministic packaging into future worker input shape

Must not include:
- worker state machine yet
- LLM integration
- scoring/pattern policy changes

### PR-W2-02
TrendReversalMonitorWorker shadow introduction

Scope:
- `TrendReversalMonitorInputV1`
- `TrendReversalObservationV1`
- validation
- feature extraction
- scoring
- state machine
- emit policy
- journal persistence

Must not include:
- decision authority changes
- execution changes
- pattern/scoring coupling
- runtime gating changes

### PR-W2-03
Worker downstream qualification hooks

Scope:
- watchlist prioritization
- candidate enrichment
- optional advisory trigger request interface

Must not include:
- direct execution triggers
- direct score overrides

## Merge gates

### Before PR-W2-02 may merge
- W1-02 green
- W1-03 green
- Wave-1 replay fixtures stable
- worker input fields available or explicitly fail-closed/degraded

### Before PR-W2-03 may merge
- worker shadow output quality reviewed
- state machine stable in replay
- fakeout/invalidation behavior tested
- no authority leak in downstream consumers
