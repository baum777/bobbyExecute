# 09 — Main Chat Migration Note

## What to carry back into the main chat

We now have enough local architectural clarity to integrate the `TrendReversalMonitorWorker` meaningfully.

### Proven current baseline
- Upper-half foundations already exist and are semantically stabilized:
  - `SourceObservation`
  - `DiscoveryEvidence`
  - `CandidateToken`
  - `UniverseBuildResult`
- Wave-1 naming and deterministic helper ownership have been aligned
- The repo still preserves deterministic authority and advisory isolation

### Correct worker interpretation
The worker should be integrated as a **deterministic observational sidecar**, not as a decision shortcut.

### Correct insertion point
Not before Wave-1 is real.
Not after decision.
The right implementation order is:
- W1-02: upstream chain + `DataQualityV1`
- W1-03: `CQDSnapshotV1`
- W2-01: signal/forensics foundation
- W2-02: `TrendReversalMonitorWorker` shadow mode
- W2-03: controlled downstream setup qualification use

### What the worker may do
- observe strong downtrend contexts
- classify reclaim / retest / reversal progression
- journal typed `TrendReversalObservationV1`
- request shadow advisory / setup review
- enrich watchlists and candidate priority

### What the worker may not do
- authorize execution
- override policy/risk
- bypass guardrails
- directly place trades

## How to use this bundle in the repo discussion
Tell the main chat:
1. This is a **spec/docs add-on bundle**, not a code import bundle.
2. It adapts the worker idea to the actual implementation state already reached.
3. It recommends integrating the worker in **Wave 2 shadow mode**, after Wave-1 quality/CQD are in place.
4. It keeps the worker observational and journal-first.
5. It preserves the main law:

```text
LLM discovers.
Deterministic logic decides.
Governance authorizes.
Execution verifies.
Journal remembers.
Learning improves offline.
```

## Suggested one-paragraph handoff text

We have enough upper-half foundation now to place the TrendReversalMonitorWorker safely, but not as a direct decision shortcut. The correct integration is as a deterministic, journaled, shadow-first observational worker that lands after Wave-1 DataQuality and CQD, then feeds setup qualification, watchlist prioritization, and optional advisory triggering — never direct execution. The attached docs bundle captures the adapted spec, contract shape, phase plan, tests, and allowed/forbidden downstream uses.
