# BobbyExecute v2 — Trend Reversal Worker Integration Bundle

This bundle adapts the current BobbyExecute v2 implementation plan to the actual implementation status reached so far:

- PR-01: v2 scaffold structure and contract zone
- PR-02: first real upper-half foundation (`SourceObservation`, `DiscoveryEvidence`, `CandidateToken`, `UniverseBuildResult`)
- PR-02b: semantics stabilization (`status` + `isStale`, deterministic notes, barrel hygiene)
- PR-W1-01: Wave-1 contract spine and deterministic helper alignment

## Purpose

This bundle defines how to integrate a **deterministic TrendReversalMonitorWorker** into the BobbyExecute v2 pipeline **without authority leakage**.

The worker is treated as:
- deterministic
- evidence-first
- journalable
- shadow/paper-first
- non-LLM
- non-authoritative

It is not a trade executor and not a policy bypass.

## Bundle contents

- `01_IMPLEMENTATION_STATUS_AND_GAP.md`
- `02_WORKER_POSITION_IN_PIPELINE.md`
- `03_TREND_REVERSAL_WORKER_SPEC.md`
- `04_CONTRACTS_AND_ARTIFACTS.md`
- `05_ADJUSTED_IMPLEMENTATION_PLAN.md`
- `06_PR_AND_PHASE_PLAN.md`
- `07_TEST_AND_GOVERNANCE_PLAN.md`
- `08_ALLOWED_FORBIDDEN_TRIGGER_PATHS.md`
- `09_MAIN_CHAT_MIGRATION_NOTE.md`

## Core principle

```text
The worker may trigger observation, prioritization, shadow advisory, and setup qualification.
It may never trigger execution authority on its own.
```
