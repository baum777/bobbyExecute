# 04 — Contracts and Artifacts

## Primary artifact to add

Introduce a new observational artifact:

```ts
TrendReversalObservationV1
```

This should remain a standalone typed artifact rather than being merged directly into `SignalPackV1`.

## Why standalone first?

If merged too early into a generic signal pack, the worker's specialized semantics get blurred with generic microstructure/forensics.
A standalone artifact is safer because it:
- preserves specialized meaning
- keeps worker lifecycle separate
- makes journaling/replay clearer
- prevents premature decision coupling

## Proposed contract

```ts
interface TrendReversalObservationV1 {
  artifact_type: "trend_reversal_observation";
  artifact_version: "1.0.0";

  asset_id: string;
  timestamp: string;

  should_monitor: boolean;
  trend_context: "strong_downtrend" | "not_strong_downtrend";

  state:
    | "not_strong_downtrend"
    | "watch_downtrend"
    | "watch_bounce_attempt"
    | "watch_reclaim_candidate"
    | "watch_retest_pending"
    | "watch_validated_shift"
    | "watch_confirmed_reversal"
    | "watch_fakeout_reject"
    | "watch_invalidated"
    | "data_degraded"
    | "data_unhealthy";

  classification:
    | "not_applicable"
    | "downtrend_continuation"
    | "bounce_attempt"
    | "early_reclaim_candidate"
    | "validated_trend_shift_setup"
    | "confirmed_reversal_candidate";

  scores: {
    market_structure_score: number;
    onchain_score: number;
    quality_score: number;
    fakeout_penalty: number;
    total_score: number;
  };

  features: Record<string, boolean | number | string>;

  validation: {
    quality_pass: boolean;
    hard_fail: boolean;
    degraded: boolean;
    failed_gates: string[];
  };

  next_confirmation_needed: string[];
  invalidation_conditions: string[];
  evidence: Record<string, number | string>;
  evidence_refs?: string[];
  previous_state?: string;
}
```

## Supporting contracts

### `TrendReversalMonitorInputV1`
The worker input should be defined as a typed contract and versioned, but implementation may begin with a narrower subset depending on adapter availability.

### `TrendReversalMaterialChangeV1`
Optional small event artifact for emit policy:
- state change
- score jump
- reclaim event
- invalidation event

### `TrendReversalWorkerStateV1`
Persisted worker state to keep prior state outside ephemeral memory:
- asset id
- previous state
- previous score
- last emitted markers
- last material event time

## Journal expectation

`TrendReversalObservationV1` must be journalable from the first implementation phase.
It does not need to be canonical decision truth, but it must be:
- hashable
- append-only storable
- replayable
- linked by trace/asset/time
