# 03 — TrendReversalMonitorWorker Spec (Adapted to Current Implementation)

## Purpose

Observe assets already in a strong downtrend and classify whether they remain in continuation, form a dead bounce, attempt a reclaim, validate a shift, or confirm a reversal.

## Non-authority posture

The worker:
- does not decide
- does not execute
- does not size
- does not set policy
- does not override risk
- does not issue a decision token

It only emits a typed observation artifact.

## Deterministic role

The worker is a deterministic observer with:
- strict validation
- explicit quality semantics
- stable score matrix
- explicit state machine
- controlled emission rules

## Activation universe

The worker should only run when a candidate is already in a strong downtrend context.

### Strong-downtrend context default rule
At least **4 of 6** must hold:
- lower-high sequence present
- lower-low sequence present
- price below EMA20 and BB midline
- negative trend slope over 15m candles
- repeated reclaim failures
- relative drawdown from local swing high

If not true:
- `should_monitor = false`
- `classification = not_applicable`
- `state = not_strong_downtrend`

## Input posture relative to current repo

The current repo does not yet have all final V2 artifacts wired, so the worker should be specified against a future-facing input contract but implemented in phases.

### Phase-A input reality
Use currently available and future-near fields from:
- market adapters
- candles
- holder stats
- trade flow stats
- smart wallet stats
- market indicators
- trend line derivations
- freshness / consensus metadata

### Phase-A implementation rule
If some future fields are not yet available in production wiring, the worker must remain:
- shadow-only
- fail-closed on missing hard inputs
- explicit about degraded mode

## Score system

The worker should keep the proposed deterministic matrix:
- market structure score
- onchain participation score
- quality score
- fakeout penalty
- total score = structure + onchain + quality - fakeout

This is appropriate for BobbyExecute because it is:
- explicit
- testable
- replayable
- versionable

## State machine

Keep the proposed state machine because it creates operationally meaningful observational states:
- `watch_downtrend`
- `watch_bounce_attempt`
- `watch_reclaim_candidate`
- `watch_retest_pending`
- `watch_validated_shift`
- `watch_confirmed_reversal`
- `watch_fakeout_reject`
- `watch_invalidated`
- `data_degraded`
- `data_unhealthy`

## Emission policy

Do not emit on every loop.
Emit only on:
- state changes
- material score jumps
- first reclaim / retest / higher-low / confirmed reversal
- invalidation

This protects journal, alerts, and downstream qualification from noise.

## Design law

```text
Break shows intent.
Retest shows durability.
Onchain participation shows truth.
The worker records this.
It does not authorize action.
```
