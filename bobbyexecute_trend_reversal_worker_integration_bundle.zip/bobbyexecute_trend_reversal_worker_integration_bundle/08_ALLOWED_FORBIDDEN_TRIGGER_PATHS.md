# 08 — Allowed and Forbidden Trigger Paths

## Allowed downstream uses
The worker may trigger or enrich:
- watchlist prioritization
- candidate enrichment
- setup qualification context
- shadow advisory requests
- alerting
- journaling
- operator visibility

## Conditionally allowed later
Only after typed bridge work lands:
- selected worker features may enter `ConstructedSignalSetV1`
- selected worker outputs may influence scoring/pattern indirectly through typed deterministic mapping

## Forbidden uses
The worker may never directly:
- place orders
- set `EXECUTE`
- set `DecisionResultV1.disposition`
- set or mutate `DecisionTokenV1`
- override risk or guardrails
- set position size
- bypass review gates
- act as a direct policy input without a later approved typed bridge

## Correct interpretation of “trigger the bot / LLM”
In BobbyExecute-safe language, the worker may:
- trigger a **shadow advisory evaluation**
- trigger a **setup review path**
- trigger a **candidate/watchlist promotion**

It may not trigger execution.
