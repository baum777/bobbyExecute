# 02 — Worker Position in the Pipeline

## Recommended position

The worker should be inserted as a deterministic observational stage between the upper-half evidence/quality path and the later scoring/pattern stack.

## Preferred stage position

```text
Stage 0: Source Observation
Stage 1: Candidate Discovery
Stage 2: Normalize + Universe Builder
Stage 3: Data Quality + Cross-Source Confidence
Stage 4: CQD Build
Stage 5: Context + Forensics / SignalPack foundation
Stage 5.5: TrendReversalMonitorWorker
Stage 6: LLM Signal Discovery (optional advisory)
Stage 7: ScoreCard
Stage 8: Pattern Classification
Stage 9: Sizing
Stage 10+: deterministic decision / token / execute / verify / journal
```

## Why not earlier?

The worker requires:
- validated freshness
- consensus checks
- downtrend context features
- flow / holder / liquidity / line data
- explicit evidence references

Without Stage 3+ style discipline, it would become a fragile standalone heuristic.

## Why not later?

If it is inserted only after scoring/pattern, the worker loses its value as a **setup observation and prioritization component**.
Its real purpose is to provide a disciplined, specialized *reversal watch artifact* that can later enrich signal construction and candidate prioritization.

## Integration mode

### First integration mode
- shadow only
- journal-first
- no decision effect
- no execution effect
- optional material-change emit

### Second integration mode
- setup qualification input only
- may raise candidate priority or request advisory evaluation
- still not a direct policy/execute input

### Third integration mode
- selected features may be consumed via typed signal construction
- still cannot alone authorize score/pattern/policy decisions
