# 01 — Current Implementation Status and Gap Assessment

## Current implementation status

The current BobbyExecute v2 line is no longer in pure planning. The following are already established:

### Established foundations
- `SourceObservation`
- `DiscoveryEvidence`
- `CandidateToken`
- `UniverseBuildResult`
- early `DataQualityV1` ownership line
- early `CQDSnapshotV1` ownership line
- discovery / intelligence / decision / learning folder structure
- deterministic helper ownership remains singular in `bot/src/core/*`
- no runtime authority leakage from upper-half scaffolds

### Semantics already stabilized
- `SourceObservation` now separates `status` from `isStale`
- `DiscoveryEvidence` preserves missing vs disagreement vs stale semantics explicitly
- deterministic helper outputs have been tightened
- barrel and root export hygiene are guarded by tests
- migration truthfulness markers were updated

### Not yet implemented
- real `DataQualityV1` evaluation path
- real `CQDSnapshotV1` build path
- `ContextPackV1`
- `SignalPackV1`
- `AdvisoryDiscoveryV1` in Stage 6
- `ConstructedSignalSetV1`
- trend-reversal monitoring
- decision-token-gated use of new upper-half artifacts

## Strategic gap

The upper-half is now structurally and semantically stable enough to host a specialized observational worker, but it is still missing the first deterministic setup-monitoring component that can:
- watch strong downtrend contexts
- observe structural reclaim attempts
- track confirmation/fakeout transitions
- raise *qualified observation signals* upstream of scoring/pattern/decision

That is the correct gap for the `TrendReversalMonitorWorker`.

## Why the worker belongs now

It is implementable **before** LLM advisory and **before** execution gating changes because:
- it is deterministic
- it is observational only
- it fits shadow mode naturally
- it can consume Wave-1 artifacts plus market/onchain inputs without changing authority

## Why the worker does *not* belong in the decision core yet

The worker still depends on later-stage discipline:
- quality gating must be explicit
- signal/forensics inputs must be well-typed
- downstream use must be controlled

Therefore, the worker should enter first as a **journaled observational sidecar** and only later feed setup qualification.
