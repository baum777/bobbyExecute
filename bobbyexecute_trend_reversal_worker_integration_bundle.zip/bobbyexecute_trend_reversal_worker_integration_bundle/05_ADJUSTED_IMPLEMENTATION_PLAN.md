# 05 — Adjusted Implementation Plan

## Current baseline

Already done:
- PR-01 scaffold
- PR-02 upper-half foundation
- PR-02b semantic stabilization
- PR-W1-01 Wave-1 spine alignment

## Adjustment principle

The worker must be integrated **after** the Wave-1 upstream chain becomes real, but **before** any attempt to let LLM or downstream setup logic react to reversal conditions.

## Adjusted phase sequence

### W1-02 (already the next logical main step)
Build the coherent upstream chain:
- `SourceObservation`
- `DiscoveryEvidence`
- `CandidateToken`
- `UniverseBuildResult`
- real `DataQualityV1`

### W1-03
Build `CQDSnapshotV1` boundary and replay fixtures.

### W2-01
Introduce `SignalPackV1` / forensics foundation sufficient for:
- liquidity delta
- volume delta
- holder growth
- concentration deltas
- smart wallet bias
- line reclaim inputs

### W2-02
Introduce `TrendReversalMonitorWorker` in **shadow mode only**.

Deliverables:
- worker contracts
- validation gates
- feature extraction
- scoring functions
- state machine
- material-change emit policy
- journal integration
- no score/policy/execute use yet

### W2-03
Allow the worker to produce **setup qualification context** only.

Allowed downstream:
- candidate prioritization
- watchlist surfacing
- shadow advisory trigger request
- setup qualification metadata

Not allowed:
- direct score mutation
- pattern forcing
- policy overrides
- execution effects

### W3
Only after observation quality is proven:
- optional Stage-6 advisory may read CQD + Context + SignalPack + TrendReversalObservation
- still non-authoritative

### W4+
Later, selected typed features from the worker may enter signal construction and downstream scoring/patterns.

## Why this ordering is correct

Because the worker is:
- deterministic enough to land before LLM
- specialized enough to deserve its own artifact first
- too semantically strong to be injected directly into scoring/policy without observation history and replay evaluation
