# 07 — Test and Governance Plan

## Required test groups for the worker

### 1. Validation tests
Prove:
- hard gates fail closed
- degraded vs unhealthy states are explicit
- stale data and consensus failures are preserved

### 2. Feature extraction tests
Prove:
- reclaim detection is deterministic
- higher-low / lower-high transitions are stable
- holder/flow derived metrics are reproducible

### 3. Score matrix tests
Prove:
- market structure score is deterministic
- onchain score is deterministic
- quality score follows gate inputs
- fakeout penalty is additive and bounded
- same input -> same total score

### 4. State machine tests
Prove:
- legal transitions only
- rejection/invalidation rules fire correctly
- retest and confirmation transitions require the stated guards

### 5. Material-change emission tests
Prove:
- emits on state change / major score jump / reclaim / retest / invalidation
- does not spam on tiny score noise

### 6. Authority isolation tests
Prove:
- worker artifacts are not consumed as direct decision authority
- no execution path can be triggered from worker output alone
- LLM/provider absence does not affect worker semantics

### 7. Replay tests
Prove:
- journaled worker artifacts replay to same scores and same state transitions

## Governance rule

The worker is governed as:
- deterministic observational subsystem
- shadow-first
- no direct order authority
- journal-first
- promotion to downstream use only after replay and review
